package com.ourlist.app

import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class Item(
    val id: String = "", val name: String = "", val quantity: String = "",
    val note: String = "", val category: String = "Groceries", val addedBy: String = "",
    val purchased: Boolean = false, val createdAt: Long = 0
)

/** Shared list in Cloud Firestore. Offline cache is on by default and syncs when back online. */
object Repo {
    private val col get() = Firebase.firestore.collection("lists").document("family").collection("items")

    fun items(): Flow<List<Item>> = callbackFlow {
        val reg = col.orderBy("createdAt").addSnapshotListener { s, _ ->
            if (s != null) trySend(s.documents.mapNotNull { d -> d.toObject(Item::class.java)?.copy(id = d.id) })
        }
        awaitClose { reg.remove() }
    }
    fun add(i: Item) = col.add(i)
    fun setPurchased(id: String, v: Boolean) = col.document(id).update("purchased", v)
    fun delete(id: String) = col.document(id).delete()
}
