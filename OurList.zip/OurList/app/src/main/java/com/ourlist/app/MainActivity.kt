package com.ourlist.app

import android.Manifest
import android.app.TimePickerDialog
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Calendar

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF2E6B4F))) { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf(Firebase.auth.currentUser) }
    var err by remember { mutableStateOf<String?>(null) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS) }

    if (user == null) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("OurList", style = MaterialTheme.typography.displayMedium)
            Text("Family shopping list")
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(email, { email = it.trim() }, label = { Text("Email") }, singleLine = true)
            OutlinedTextField(pass, { pass = it }, label = { Text("Password (6+ characters)") }, singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { scope.launch {
                    try { Firebase.auth.signInWithEmailAndPassword(email, pass).await(); user = Firebase.auth.currentUser; err = null }
                    catch (e: Exception) { err = e.message }
                } }) { Text("Sign in") }
                OutlinedButton(onClick = { scope.launch {
                    try { Firebase.auth.createUserWithEmailAndPassword(email, pass).await(); user = Firebase.auth.currentUser; err = null }
                    catch (e: Exception) { err = e.message }
                } }) { Text("Create account") }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        }
    } else ListScreen((user!!.email ?: "Me").substringBefore("@").replaceFirstChar { it.uppercase() })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(me: String) {
    val ctx = LocalContext.current
    val all by Repo.items().collectAsState(emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var nav by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var rem by remember { mutableStateOf(Reminders.all(ctx)) }
    val shown = all.filter { it.purchased == (tab == 1) }

    Scaffold(
        topBar = { Column {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("OurList", style = MaterialTheme.typography.headlineMedium)
                    Text("Family shopping list", style = MaterialTheme.typography.bodyMedium)
                }
                all.map { it.addedBy }.distinct().take(4).forEach {
                    AssistChip(onClick = {}, label = { Text(it.take(1)) }, modifier = Modifier.padding(start = 4.dp))
                }
            }
            if (nav == 0) TabRow(tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("To buy (${all.count { !it.purchased }})") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Purchased (${all.count { it.purchased }})") })
            }
        } },
        bottomBar = { NavigationBar {
            NavigationBarItem(nav == 0, { nav = 0 }, { Icon(Icons.Default.ShoppingBasket, null) }, label = { Text("Shopping list") })
            NavigationBarItem(nav == 1, { nav = 1; rem = Reminders.all(ctx) }, { Icon(Icons.Default.Notifications, null) }, label = { Text("My reminders") })
        } },
        floatingActionButton = { if (nav == 0) ExtendedFloatingActionButton(onClick = { adding = true },
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add item") }) }
    ) { pad ->
        if (nav == 0) LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp)) {
            shown.groupBy { it.category }.forEach { (cat, list) ->
                item { Text("$cat  (${list.size})", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(vertical = 8.dp)) }
                items(list, key = { it.id }) { it ->
                    val r = rem[it.id]
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(it.purchased, { v -> Repo.setPurchased(it.id, v)
                                if (v) { Reminders.cancel(ctx, it.id); rem = Reminders.all(ctx) } })
                            Column(Modifier.weight(1f)) {
                                Text(it.name, style = MaterialTheme.typography.titleMedium)
                                if (it.quantity.isNotBlank()) Text(it.quantity)
                                if (it.note.isNotBlank()) Text(it.note, style = MaterialTheme.typography.bodySmall)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Added by ${it.addedBy}", style = MaterialTheme.typography.labelSmall)
                                    if (r != null) AssistChip(onClick = {}, label = { Text(Reminders.fmt(r.first)) },
                                        leadingIcon = { Icon(Icons.Default.Alarm, null, Modifier.size(14.dp)) }, modifier = Modifier.padding(start = 6.dp))
                                }
                            }
                            if (!it.purchased) IconButton({ pickTime(ctx) { t -> Reminders.schedule(ctx, it.id, it.name, t); rem = Reminders.all(ctx) } }) {
                                Icon(Icons.Default.AddAlarm, "Remind me") }
                            IconButton({ Repo.delete(it.id); Reminders.cancel(ctx, it.id) }) { Icon(Icons.Default.Delete, "Delete") }
                        }
                    }
                }
            }
        } else LazyColumn(Modifier.padding(pad).padding(16.dp)) {
            if (rem.isEmpty()) item { Text("No upcoming reminders. Tap the alarm icon on an item to set one for yourself.") }
            items(rem.entries.sortedBy { it.value.first }.toList()) { (id, v) ->
                ListItem(headlineContent = { Text(v.second) }, supportingContent = { Text(Reminders.fmt(v.first)) },
                    trailingContent = { IconButton({ Reminders.cancel(ctx, id); rem = Reminders.all(ctx) }) { Icon(Icons.Default.Close, "Cancel") } })
            }
        }
    }
    if (adding) AddDialog(me, { adding = false }) { item, at ->
        Repo.add(item).addOnSuccessListener { d -> if (at != null) { Reminders.schedule(ctx, d.id, item.name, at); rem = Reminders.all(ctx) } }
        adding = false
    }
}

fun pickTime(ctx: Context, onPick: (Long) -> Unit) {
    val n = Calendar.getInstance()
    TimePickerDialog(ctx, { _, h, m ->
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        onPick(c.timeInMillis)
    }, n.get(Calendar.HOUR_OF_DAY), n.get(Calendar.MINUTE), false).show()
}

@Composable
fun AddDialog(me: String, onDismiss: () -> Unit, onSave: (Item, Long?) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("Groceries") }
    var at by remember { mutableStateOf<Long?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add item") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Item name") }, singleLine = true)
            OutlinedTextField(qty, { qty = it }, label = { Text("Quantity (e.g. 2 litres)") }, singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("Note (brand, size…)") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Groceries", "Household").forEach { FilterChip(cat == it, { cat = it }, { Text(it) }) }
            }
            TextButton({ pickTime(ctx) { at = it } }) { Icon(Icons.Default.AddAlarm, null); Spacer(Modifier.width(6.dp))
                Text(at?.let { "Remind me at ${Reminders.fmt(it)}" } ?: "Remind me (only on my phone)") }
        } },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = {
            onSave(Item(name = name.trim(), quantity = qty.trim(), note = note.trim(), category = cat,
                addedBy = me, createdAt = System.currentTimeMillis()), at) }) { Text("Add") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}
