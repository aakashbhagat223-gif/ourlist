package com.ourlist.app

import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
import java.text.DateFormat
import java.util.Date

/** Personal, on-device reminders (AlarmManager). Not synced, so nobody else gets pinged. */
object Reminders {
    private fun prefs(c: Context) = c.getSharedPreferences("reminders", Context.MODE_PRIVATE)
    private fun pi(c: Context, id: String, title: String) = PendingIntent.getBroadcast(
        c, id.hashCode(), Intent(c, ReminderReceiver::class.java).putExtra("title", title).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(c: Context, id: String, title: String, at: Long) {
        c.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, id, title))
        prefs(c).edit().putString(id, "$at|$title").apply()
    }
    fun cancel(c: Context, id: String) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id, ""))
        prefs(c).edit().remove(id).apply()
    }
    /** id -> (time, title) */
    fun all(c: Context): Map<String, Pair<Long, String>> = prefs(c).all.mapNotNull { (k, v) ->
        (v as? String)?.split("|", limit = 2)?.let { k to (it[0].toLong() to it[1]) }
    }.toMap().filterValues { it.first > System.currentTimeMillis() }
    fun fmt(t: Long): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(t))
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(i.getStringExtra("id").hashCode(), NotificationCompat.Builder(c, "reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Pick up: " + i.getStringExtra("title"))
            .setContentIntent(open).setAutoCancel(true).build())
        i.getStringExtra("id")?.let { Reminders.cancel(c, it) }
    }
}
