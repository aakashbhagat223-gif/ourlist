OurList - see the chat for step-by-step phone-only instructions. Files: firestore.rules, build.yml (goes to .github/workflows/build.yml in GitHub).
